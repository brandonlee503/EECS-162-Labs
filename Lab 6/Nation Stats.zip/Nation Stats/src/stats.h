/*
 * stats.h
 *
 *  Created on: May 8, 2014
 *      Author: Zach
 */

#ifndef STATS_H_
#define STATS_H_

class stats
{
protected:
	int population;
	char *name;
	
public:
	stats();
	stats(const char *n, int pop);
	stats(stats &other);

	virtual void operator =(stats &other);
	virtual void set_pop(int pop);
	virtual void set_name(const char *n);
	virtual void display_info();

	virtual ~stats();
};

#endif /* STATS_H_ */
