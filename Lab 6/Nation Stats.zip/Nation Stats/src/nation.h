#ifndef NATION_H_
#define NATION_H_

#include "./stats.h"

class nation : public stats
{
public:
	nation();
	nation(const char *n, int pop);
	nation(nation &other);

	void operator =(nation &other);
	void set_pop(int pop);
	void set_name(const char *n);
	void display_info();

	virtual ~nation();
};

#endif
