#include "./stats.h"

#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

stats::stats()
{

}

stats::stats(const char *n, int pop)
{

}

stats::stats(stats &other)
{

}

void stats::operator =(stats &other)
{

}

void stats::set_pop(int pop)
{

}

void stats::set_name(const char *n)
{

}

void stats::display_info()
{

}

stats::~stats()
{

}

