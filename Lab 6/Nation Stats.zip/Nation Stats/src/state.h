#ifndef STATE_H_
#define STATE_H_

#include "./stats.h"

class state : public stats
{
public:
	state();
	state(const char *n, int pop);
	state(state &other);

	void operator =(state &other);
	void set_pop(int pop);
	void set_name(const char *n);
	void display_info();

	virtual ~state();
};

#endif
