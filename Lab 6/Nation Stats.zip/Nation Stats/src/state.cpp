#include "./state.h"

#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

state::state()
{
	this->population = 0;
	this->name = NULL;
}

state::state(const char *n, int pop)
{
	this->population = pop;

	delete []name;
	memcpy(this->name, n, strlen(n));
}

state::state(state &other)
{
	this->population = other.population;

	delete []name;
	memcpy(this->name, other.name, strlen(other.name));
}

void state::operator =(state &other)
{
	this->population = other.population;

	delete []name;
	memcpy(this->name, other.name, strlen(other.name));
}

void state::set_pop(int pop)
{
	this->population = pop;
}

void state::set_name(const char *n)
{
	delete []name;
	name = new char[strlen(n)];
	memcpy(name, n, strlen(n));
}

void state::display_info()
{
	cout << "Name: " << this->name << ", Population: ";
	cout << this->population << endl;
}

state::~state()
{
	this->population = 0;
	delete []name;
}

