#include "./city.h"

#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

city::city()
{
	this->population = 0;
	this->name = NULL;
}

city::city(const char *n, int pop)
{
	this->population = pop;

	delete []name;
	memcpy(this->name, n, strlen(n));
}

city::city(city &other)
{
	this->population = other.population;

	delete []name;
	memcpy(this->name, other.name, strlen(other.name));
}

void city::operator =(city &other)
{
	this->population = other.population;

	delete []name;
	memcpy(this->name, other.name, strlen(other.name));
}

void city::set_pop(int pop)
{
	this->population = pop;
}

void city::set_name(const char *n)
{
	delete []name;
	name = new char[strlen(n)];
	memcpy(name, n, strlen(n));
}

void city::display_info()
{
	cout << "Name: " << this->name << ", Population: ";
	cout << this->population << endl;
}

city::~city()
{
	this->population = 0;
	delete []name;
}

