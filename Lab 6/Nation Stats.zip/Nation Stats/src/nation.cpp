#include "./nation.h"

#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

nation::nation()
{
	this->population = 0;
	this->name = NULL;
}

nation::nation(const char *n, int pop)
{
	this->population = pop;

	delete []name;
	memcpy(this->name, n, strlen(n));
}

nation::nation(nation &other)
{
	this->population = other.population;

	delete []name;
	memcpy(this->name, other.name, strlen(other.name));
}

void nation::operator =(nation &other)
{
	this->population = other.population;

	delete []name;
	memcpy(this->name, other.name, strlen(other.name));
}

void nation::set_pop(int pop)
{
	this->population = pop;
}

void nation::set_name(const char *n)
{
	delete []name;
	name = new char[strlen(n)];
	memcpy(name, n, strlen(n));
}

void nation::display_info()
{
	cout << "Name: " << this->name << ", Population: ";
	cout << this->population << endl;
}

nation::~nation()
{
	this->population = 0;
	delete []name;
}

