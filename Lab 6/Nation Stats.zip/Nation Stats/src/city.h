#ifndef CITY_H_
#define CITY_H_

#include "./stats.h"

class city : public stats
{
public:
	city();
	city(const char *n, int pop);
	city(city &other);

	void operator =(city &other);
	void set_pop(int pop);
	void set_name(const char *n);
	void display_info();

	virtual ~city();
};

#endif
