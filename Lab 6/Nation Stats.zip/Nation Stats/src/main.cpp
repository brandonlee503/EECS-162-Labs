#include <iostream>
#include <string>

#include "./stats.h"
#include "./nation.h"
#include "./state.h"
#include "./city.h"

using namespace std;

int main()
{
	stats *stat;

	int input = 0;
	cout << "What data would you like to look at?" << endl;
	cout << "\t 1. Nation" << endl;
	cout << "\t 2. State" << endl;
	cout << "\t 3. City" << endl;
	cout << "\t1, 2, or 3? ";
	cin >> input;

	if(input == 1)
	{
		cout << "1" << endl;
		//Set stats to nation
		stat = new nation();
		stat->set_pop(316128839);
		stat->set_name("USA");
		cout << "1" << endl;
	}
	else if(input == 2)
	{
		cout << "2" << endl;
		//Set stats to state
		stat = new state();
		cout << "2" << endl;
		stat->set_pop(3930065);
		cout << "2" << endl;
		stat->set_name("Oregon");
		cout << "2" << endl;
	}
	else if(input == 3)
	{
		cout << "3" << endl;
		//Set stats to city
		stat = new city();
		stat->set_pop(54998);
		stat->set_name("Corvallis");
		cout << "3" << endl;
	}

	//Show info
	cout << "test " << endl;
	stat->display_info();

}
